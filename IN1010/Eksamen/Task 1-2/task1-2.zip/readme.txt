I have made an additional class called Items, which will serve as a container of the Item class.
I also changed the rules of the game a little bit, and added a ratio for each place, which is a percentage.
The items sold will be multiplied with this percentage.
I think this will add a strategic dimension to the game, and make it more fun.
The player must not only get the best items, but they must also find the best place that has the best ratio to sell the items at the best price.