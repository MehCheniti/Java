1. 
My program is compiled with javac *.java.

2. 
The file "Main.java" includes my main method.

3. 
None.

4. 
None.

5. 
Everything should be displayed correctly, except for slack.

6. 
Credit goes to the depth first-search slides from the lectures and the GeeksforGeeks YouTube channel.