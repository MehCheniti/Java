public class Pickup extends Kjoretoy{

  public Pickup(int registreringsnummer, String type){
    super(registreringsnummer, type);
  }

}
