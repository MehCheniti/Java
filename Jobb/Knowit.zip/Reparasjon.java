public interface Reparasjon{

  public void settBeskrivelse(String beskrivelsen);

  public void settKostnad(int kostnaden);

  public void utfortDato(int datoen);

}
