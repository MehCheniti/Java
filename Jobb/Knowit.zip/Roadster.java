public class Roadster extends Kjoretoy{

  public Roadster(int registreringsnummer, String type){
    super(registreringsnummer, type);
  }

}
