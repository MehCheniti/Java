public class SUV extends Kjoretoy{

  public SUV(int registreringsnummer, String type){
    super(registreringsnummer, type);
  }

}
